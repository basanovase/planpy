# planpy

An open source library for project management


Usage:


import planpy

new_project = planpy.project("My new project")
