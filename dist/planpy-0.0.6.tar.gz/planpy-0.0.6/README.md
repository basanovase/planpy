planpy

An open source library for project management. The intention for this project is pandas integration for report and visualisations in a GANT type format, alongside native reporting


Usage:


import planpy

new_project = planpy.project("My new project")
