<h1>planpy</h1>

An open source library for project management. The intention for this project is pandas integration for report and visualisations in a GANT type format, alongside native reporting


<h2>Usage:</h2>


import planpy

new_project = planpy.project("My new project")
