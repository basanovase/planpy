import pandas as pd



class risk:

    """Main class to add project risks

    """
    def __init__(self,name,project):
        self.name = project_name
        self.project = project


class task:
    """Main task class of library.

            Inititlise a new project:
                Methods can then be added off task

    """
    def __init__(self, name, project):
        self.name = name
        self.project = project


    def add_start_date(self, start_date):
        self.start_date = start_date
        return start_date


    def add_end_date(self, end_date)
        self.end_date = end_date
        return self.end_date

    def add_budget(self, budget):
        self.subject = subject
        return self.subject

    def assigned_to(self, assigned):
        self.assigned = assigned
        return self.assigned

    def business_owner(self, business_owner):
        self.business_owner = business_owner
        return self.business_owner

class project:

    """
    Main project class of library.

        Initialise a new project:
            Methods can then be added off the project and visualised.

    """

    def __init__(self,project_name, start_date, end_date, budget, project_manager):
        self.project_name = project_name





    def add_budget():
        pass

    def add_project_manager():
        pass


    def add_task():

        pass

    def remove_task():

        pass

    def add_risk():
        pass

    def show_timeline():

        pass

    def send_reminders():

        pass
